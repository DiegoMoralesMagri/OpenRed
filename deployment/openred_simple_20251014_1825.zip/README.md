# 🚀 OpenRed - Package Simple

## Installation Rapide

1. **Décompressez** ce package
2. **Uploadez** tous les fichiers sur votre hébergeur web
3. **Accédez** à votre site - OpenRed sera opérationnel !

## 📁 Répertoires Recommandés

- **O2Switch**: `/public_html/openred/`
- **OVH**: `/www/openred/`
- **Autres**: `/public_html/openred/`

## 🔗 Accès

Après upload : `http://votre-domaine.com/openred`

## ✅ Compatibilité

- Tous hébergeurs web
- Python WSGI (recommandé)  
- HTML statique (fallback automatique)

---

**OpenRed Simple Deployment**  
Package créé le: 14/10/2025 à 18:25
