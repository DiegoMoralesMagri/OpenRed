#!/usr/bin/env python3
import os
import json
from datetime import datetime

def application(environ, start_response):
    """Application WSGI simple"""
    
    path = environ.get('PATH_INFO', '/')
    
    if path.startswith('/api/'):
        content = json.dumps({
            'status': 'running',
            'app': 'OpenRed',
            'timestamp': datetime.now().isoformat()
        })
        headers = [('Content-type', 'application/json')]
    else:
        content = get_html()
        headers = [('Content-type', 'text/html; charset=utf-8')]
    
    start_response('200 OK', headers)
    return [content.encode('utf-8')]

def get_html():
    return """<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OpenRed - Déployé</title>
    <style>
        body { 
            font-family: Arial, sans-serif; margin: 0; padding: 0;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh; display: flex; align-items: center; justify-content: center;
        }
        .container {
            background: white; border-radius: 15px; padding: 40px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2); text-align: center; max-width: 600px;
        }
        h1 { color: #667eea; font-size: 3em; margin-bottom: 20px; }
        .success { 
            background: #4CAF50; color: white; padding: 20px; 
            border-radius: 10px; margin: 20px 0; font-size: 1.2em; 
        }
        .btn {
            background: #667eea; color: white; border: none; padding: 15px 30px;
            border-radius: 8px; cursor: pointer; margin: 10px; font-size: 1em;
        }
        .btn:hover { background: #764ba2; }
        .grid { 
            display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); 
            gap: 20px; margin: 30px 0; 
        }
        .card { background: #f8f9ff; padding: 20px; border-radius: 8px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🚀 OpenRed</h1>
        <div class="success">✅ Déployé avec succès sur votre hébergeur !</div>
        
        <p>Votre application OpenRed est maintenant <strong>en ligne</strong> et accessible depuis le web.</p>
        
        <div class="grid">
            <div class="card">
                <h3>🌐 Status</h3>
                <p>Application opérationnelle</p>
                <button class="btn" onclick="testAPI()">Test API</button>
            </div>
            <div class="card">
                <h3>⚡ Performance</h3>
                <p>Optimisé production</p>
                <button class="btn" onclick="showInfo()">Infos</button>
            </div>
            <div class="card">
                <h3>📱 Mobile</h3>
                <p>Interface responsive</p>
                <button class="btn" onclick="testMobile()">Test</button>
            </div>
        </div>
        
        <div style="margin-top: 30px; color: #666;">
            <p>OpenRed Universal Deployment - Installation réussie</p>
        </div>
    </div>

    <script>
        async function testAPI() {
            try {
                const response = await fetch('./api/status');
                const data = await response.json();
                alert('✅ API fonctionne !\n\nStatus: ' + data.status + '\nTimestamp: ' + data.timestamp);
            } catch (error) {
                alert('❌ Erreur API: ' + error.message);
            }
        }
        
        function showInfo() {
            alert('📊 Informations\n\n✅ Déploiement automatique réussi\n🌐 Application en ligne\n🔧 Prêt pour production');
        }
        
        function testMobile() {
            alert('📱 Compatible Mobile !\n\n✅ Design responsive\n✅ Interface adaptative\n✅ Compatible tous appareils');
        }
    </script>
</body>
</html>"""

if __name__ == '__main__':
    import wsgiref.handlers
    wsgiref.handlers.CGIHandler().run(application)
