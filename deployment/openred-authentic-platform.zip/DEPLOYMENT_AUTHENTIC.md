# 🌐 OpenRed AUTHENTIC Platform - Guide de Déploiement

## ⚠️ IMPORTANT - Système AUTHENTIQUE

Ce package contient le **VRAI système OpenRed** avec tous les protocoles établis :

- ✅ **FastAPI Backend** complet et fonctionnel
- ✅ **Protocoles de friendship** authentiques  
- ✅ **Système d'authentification** OpenRed
- ✅ **Interface sociale** complète
- ✅ **Architecture P2P** respectée intégralement

## 🚀 Déploiement Hébergement Mutualisé

### Prérequis OBLIGATOIRES
- Python 3.8+ avec pip
- Accès shell/SSH à votre hébergeur
- Support FastAPI/ASGI

### Installation Étape par Étape

1. **Extraction du package**
   ```bash
   unzip openred-authentic-platform.zip
   cd openred-authentic-platform
   ```

2. **Lancement automatique**
   ```bash
   chmod +x deploy_mutualized.sh
   ./deploy_mutualized.sh
   ```

3. **Vérification**
   - Backend API: http://votre-domaine.com:8000
   - Interface: http://votre-domaine.com:8000/web/frontend/login.html

## 🔐 Fonctionnalités AUTHENTIQUES

- **Login sécurisé** avec tokens OpenRed
- **Profils utilisateurs** respectant les protocoles
- **Système d'amitié** P2P avec permissions
- **Chat en temps réel** via WebSockets
- **Découverte de nœuds** selon architecture établie
- **URN Phantom** pour partage sécurisé

## ⚠️ Sécurité Production

1. Configurez HTTPS obligatoirement
2. Modifiez les clés par défaut dans core/auth
3. Implémentez rate limiting
4. Sauvegardez les données utilisateurs

## 📖 Architecture Respectée

Ce déploiement respecte INTÉGRALEMENT :
- Les protocoles de communication établis
- L'architecture P2P conçue
- Les standards de sécurité OpenRed
- Les interfaces utilisateur développées

## 🆘 Support

Pour toute question sur ce déploiement AUTHENTIQUE :
- Documentation: https://github.com/DiegoMoralesMagri/OpenRed
- Issues: https://github.com/DiegoMoralesMagri/OpenRed/issues

**Ce n'est PAS une version simplifiée ou alternative !**
**C'est le VRAI système OpenRed en production !**
