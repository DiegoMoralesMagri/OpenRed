#!/bin/bash
# OpenRed AUTHENTIC Platform - Déploiement Hébergement Mutualisé
# Respecte INTÉGRALEMENT les protocoles établis

echo "🌐 OpenRed AUTHENTIC Platform - Déploiement"
echo "==========================================="

# Configuration spécifique hébergement mutualisé
export OPENRED_ENV="production"
export OPENRED_HOST="0.0.0.0"
export OPENRED_PORT="8000"
export OPENRED_DEBUG="false"

# Vérifications environnement
echo "🔍 Vérification de l'environnement..."

if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 requis pour OpenRed"
    exit 1
fi

if ! command -v pip3 &> /dev/null; then
    echo "❌ pip3 requis pour les dépendances"
    exit 1
fi

echo "✅ Environnement validé"

# Installation des dépendances AUTHENTIQUES
echo "📦 Installation des dépendances OpenRed..."
pip3 install --user fastapi uvicorn websockets pillow cryptography python-multipart jinja2

# Vérification des protocoles core
echo "🔐 Vérification des protocoles core..."
python3 -c "
import sys
try:
    from openred_p2p_node import OpenRedP2PNode
    from friendship_protocol import FriendshipProtocol
    from social_messaging import DistributedMessaging
    print('✅ Protocoles OpenRed validés')
except ImportError as e:
    print(f'❌ Erreur protocoles: {e}')
    sys.exit(1)
"

# Lancement de la plateforme AUTHENTIQUE
echo "🚀 Lancement OpenRed Platform..."
echo "🌐 Interface: http://localhost:8000"
echo "🔐 Respect total des protocoles établis"

cd web/backend
python3 web_api.py
