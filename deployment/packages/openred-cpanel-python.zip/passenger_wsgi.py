import sys
import os
from pathlib import Path

# Configuration Passenger
app_dir = Path(__file__).parent
sys.path.insert(0, str(app_dir))

try:
    from app import application
except ImportError:
    # Fallback WSGI simple
    def application(environ, start_response):
        status = '200 OK'
        headers = [('Content-type', 'text/html')]
        start_response(status, headers)
        
        return [b"""
        <!DOCTYPE html>
        <html>
        <head><title>OpenRed Platform</title></head>
        <body style="font-family: Arial; text-align: center; background: #1a1a2e; color: white; padding: 50px;">
            <h1>🌐 OpenRed Platform</h1>
            <p>Déploiement cPanel réussi - Système en cours d'initialisation</p>
        </body>
        </html>
        """]
