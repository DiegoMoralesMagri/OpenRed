# 🌐 OpenRed Social Platform - Hébergement Mutualisé

## Installation Rapide

1. **Décompressez** ce package dans votre dossier web
2. **Assurez-vous** que PHP est activé sur votre hébergeur
3. **Visitez** votre site : `http://votre-domaine.com`

## Fonctionnalités

- 🔐 **Système de connexion** sécurisé
- 👤 **Profils utilisateurs** personnalisables  
- 👥 **Gestion d'amis** et demandes
- 💬 **Chat en temps réel** P2P
- 🌐 **Découverte de nœuds** du réseau
- 📱 **Interface responsive** mobile

## Structure

```
/
├── index.html          # Page d'accueil
├── login.html          # Connexion
├── dashboard.html      # Tableau de bord
├── profile.html        # Profil utilisateur
├── friends.html        # Gestion des amis
├── api.php            # Routeur API PHP
├── api/               # APIs backend
│   ├── login.php      # Authentification
│   └── ...            # Autres endpoints
└── data/              # Données utilisateurs
```

## Support

- 📖 Documentation : https://github.com/DiegoMoralesMagri/OpenRed
- 🐛 Issues : https://github.com/DiegoMoralesMagri/OpenRed/issues
- 💬 Discussions : https://github.com/DiegoMoralesMagri/OpenRed/discussions

## Sécurité

⚠️ **Important** : Ce package est une version de démonstration.
Pour la production, implémentez :
- Base de données sécurisée
- Hashage des mots de passe
- Validation CSRF
- Rate limiting
