<?php
// OpenRed Social Platform - Configuration PHP
// Compatible avec hébergement mutualisé

// Configuration de base
ini_set('display_errors', 0);
error_reporting(E_ALL & ~E_NOTICE);

// Headers CORS pour API
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization');
    exit(0);
}

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json');

// Routeur simple pour API
$request = $_SERVER['REQUEST_URI'];
$path = parse_url($request, PHP_URL_PATH);

// Routes API
switch ($path) {
    case '/api/login':
        include 'api/login.php';
        break;
    case '/api/register':
        include 'api/register.php';
        break;
    case '/api/profile':
        include 'api/profile.php';
        break;
    case '/api/friends':
        include 'api/friends.php';
        break;
    case '/api/nodes':
        include 'api/nodes.php';
        break;
    default:
        http_response_code(404);
        echo json_encode(['error' => 'Route not found']);
        break;
}
?>