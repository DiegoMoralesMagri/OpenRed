<?php
// API Login OpenRed
$data = json_decode(file_get_contents('php://input'), true);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $data['username'] ?? '';
    $password = $data['password'] ?? '';
    
    // Validation simple (à améliorer en production)
    if (strlen($username) >= 3 && strlen($password) >= 6) {
        $user = [
            'id' => uniqid(),
            'username' => $username,
            'status' => 'online',
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        // Sauvegarde simple en fichier (à remplacer par base de données)
        $users_file = 'data/users.json';
        if (!file_exists('data')) mkdir('data', 0755, true);
        
        $users = [];
        if (file_exists($users_file)) {
            $users = json_decode(file_get_contents($users_file), true) ?? [];
        }
        $users[$username] = $user;
        file_put_contents($users_file, json_encode($users));
        
        echo json_encode(['success' => true, 'user' => $user]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Nom d'utilisateur ou mot de passe invalide']);
    }
} else {
    echo json_encode(['error' => 'Method not allowed']);
}
?>