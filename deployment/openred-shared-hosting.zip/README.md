# 🌐 OpenRed - Hébergement Mutualisé

## Installation Rapide

1. **Téléchargez** ce package sur votre ordinateur
2. **Décompressez** le fichier ZIP
3. **Uploadez** tous les fichiers vers votre hébergement web
4. **Accédez** à votre site - OpenRed est prêt !

## Hébergeurs Compatibles

✅ **OVH** - Installation automatique
✅ **O2Switch** - Compatible CGI
✅ **1&1 IONOS** - Support Python
✅ **Hostinger** - Fonctionne parfaitement
✅ **Gandi** - Compatible
✅ **Any shared hosting** - Avec support CGI/Python

## Structure des Fichiers

```
votre-site.com/
├── index.html          # Page d'accueil OpenRed
├── app/
│   ├── index.html      # Interface web principale
│   ├── api.cgi         # API OpenRed (exécutable)
│   └── config.json     # Configuration
└── install.sh          # Script d'installation
```

## Configuration

### Permissions Requises
- Dossiers: `755` (rwxr-xr-x)
- Fichiers: `644` (rw-r--r--)
- Scripts CGI: `755` (rwxr-xr-x)

### Requirements Hébergeur
- Python 3.x (disponible sur la plupart des hébergeurs)
- Support CGI (généralement activé par défaut)
- Accès FTP/SFTP pour upload

## Utilisation

1. **Page d'accueil**: `https://votre-site.com/`
2. **Interface OpenRed**: `https://votre-site.com/app/`
3. **API**: `https://votre-site.com/app/api.cgi`

## Fonctionnalités Disponibles

🖼️ **Images PHANTOM** - Protection anti-capture
🔥🦅 **URN Phoenix** - Fragmentation quantique  
🕷️ **Spider Protocol** - Navigation P2P
🔐 **P2P Asymétrique** - Sécurité 4 clés RSA

## Support

- 📧 **Email**: support@openred.dev
- 🌐 **GitHub**: https://github.com/DiegoMoralesMagri/OpenRed
- 📖 **Documentation**: https://docs.openred.dev

## Troubleshooting

### Erreur 500
- Vérifiez les permissions des fichiers CGI (755)
- Assurez-vous que Python est disponible
- Contactez votre hébergeur pour activer CGI

### Page blanche
- Vérifiez que tous les fichiers sont uploadés
- Consultez les logs d'erreur de votre hébergeur

---
**OpenRed** - Révolution P2P Décentralisée 🚀
