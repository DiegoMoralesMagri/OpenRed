#!/bin/bash
# 🌐 Installation automatique OpenRed - Hébergement mutualisé
# Compatible: OVH, O2Switch, 1&1, etc.

echo "🌐 Installation OpenRed - Hébergement mutualisé"
echo "================================================"

# Détection automatique de l'environnement
if [[ -d "$HOME/www" ]]; then
    WEB_ROOT="$HOME/www"
    echo "✅ OVH détecté"
elif [[ -d "$HOME/public_html" ]]; then
    WEB_ROOT="$HOME/public_html"
    echo "✅ Hébergement partagé détecté"
elif [[ -d "/var/www/html" ]]; then
    WEB_ROOT="/var/www/html"
    echo "✅ VPS détecté"
else
    WEB_ROOT="$HOME/openred"
    echo "📁 Installation locale"
    mkdir -p "$WEB_ROOT"
fi

# Copier les fichiers
echo "📂 Installation dans: $WEB_ROOT"

# Rendre les scripts CGI exécutables
chmod +x app/*.cgi

# Configuration des permissions
if [[ -d "app" ]]; then
    chmod -R 755 app/
    echo "✅ Permissions configurées"
fi

echo ""
echo "🎉 Installation terminée!"
echo "🌐 Accédez à votre site pour voir OpenRed"
echo "📋 Interface admin: /app/"
echo ""
echo "🔧 Configuration hébergeur:"
echo "   - Activez Python/CGI si nécessaire"
echo "   - Vérifiez les permissions (755 pour les dossiers, 644 pour les fichiers)"
echo "   - Les scripts .cgi doivent être exécutables (755)"
