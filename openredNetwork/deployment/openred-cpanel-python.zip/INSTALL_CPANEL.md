# 🌐 OpenRed - Installation cPanel Python App

## 📋 Prérequis
- Hébergement avec cPanel
- Support Python 3.8+ 
- Gestionnaire d'applications Python activé

## 🚀 Installation Étape par Étape

### 1. Accéder au gestionnaire Python
- Connectez-vous à cPanel
- Recherchez "Python App" ou "Setup Python App"
- Cliquez sur "Create Application"

### 2. Configuration de l'application
- **Python version:** 3.8 ou supérieur
- **Application root:** `/public_html/openred` (ou sous-domaine)
- **Application URL:** votre-domaine.com/openred
- **Application startup file:** `app.py`
- **Application Entry point:** `application`

### 3. Déploiement des fichiers
- Décompressez `openred-cpanel-python.zip`
- Uploadez TOUS les fichiers dans le répertoire de l'application
- Assurez-vous que `app.py` est à la racine

### 4. Installation des dépendances
Dans le terminal cPanel ou interface Python :
```bash
pip install -r requirements.txt
```

### 5. Démarrage de l'application
- Cliquez sur "START APP" dans le gestionnaire Python
- L'application sera accessible à l'URL configurée

## 🔗 Accès à OpenRed

- **Interface principale:** `http://votre-domaine.com/openred/`
- **Page de connexion:** `http://votre-domaine.com/openred/web/frontend/login.html`
- **API Status:** `http://votre-domaine.com/openred/api/status`

## 🎯 Fonctionnalités Disponibles

✅ **Système d'authentification** complet
✅ **Profils utilisateurs** avec gestion de confidentialité  
✅ **Protocoles P2P** friendship authentiques
✅ **Interface sociale** complète (dashboard, amis)
✅ **APIs REST** fonctionnelles
✅ **Système de messaging** distribué

## ⚠️ Notes Importantes

- **Redémarrage:** Utilisez le gestionnaire Python cPanel
- **Logs:** Consultables via l'interface cPanel
- **Mise à jour:** Remplacez les fichiers et redémarrez
- **Permissions:** Gérées automatiquement par cPanel

## 🆘 Support

- Documentation: https://github.com/DiegoMoralesMagri/OpenRed
- Issues: https://github.com/DiegoMoralesMagri/OpenRed/issues

**Ceci est le VRAI système OpenRed en production !**
