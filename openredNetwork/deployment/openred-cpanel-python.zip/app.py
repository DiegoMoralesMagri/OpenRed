#!/usr/bin/env python3
"""
OpenRed cPanel Python Application
Point d'entrée pour le gestionnaire d'applications Python cPanel
"""

import sys
import os
from pathlib import Path

# Ajouter le répertoire courant au path
app_dir = Path(__file__).parent
sys.path.insert(0, str(app_dir))

# Import du système OpenRed
try:
    from web.backend.web_api import app
    
    # Configuration pour cPanel
    if __name__ == "__main__":
        import uvicorn
        uvicorn.run(
            app, 
            host="0.0.0.0", 
            port=int(os.environ.get("PORT", 8000)),
            log_level="info"
        )
    
    # Export pour WSGI/ASGI
    application = app
    
except ImportError as e:
    print(f"Erreur import OpenRed: {e}")
    
    # Fallback simple pour cPanel
    from flask import Flask, jsonify, render_template_string
    
    app = Flask(__name__)
    
    @app.route('/')
    def home():
        return render_template_string("""
        <!DOCTYPE html>
        <html>
        <head>
            <title>OpenRed Platform</title>
            <style>
                body { font-family: Arial, sans-serif; background: #1a1a2e; color: white; text-align: center; padding: 50px; }
                .container { max-width: 600px; margin: 0 auto; }
                .logo { font-size: 3em; margin-bottom: 20px; }
                .status { background: #16213e; padding: 20px; border-radius: 10px; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="logo">🌐 OpenRed</div>
                <div class="status">
                    <h2>Plateforme en cours de démarrage...</h2>
                    <p>Le système OpenRed authentique est en cours d'initialisation.</p>
                    <p><strong>Status:</strong> Déploiement cPanel réussi</p>
                </div>
            </div>
        </body>
        </html>
        """)
    
    @app.route('/api/status')
    def api_status():
        return jsonify({
            'status': 'online',
            'platform': 'OpenRed cPanel',
            'mode': 'fallback'
        })
    
    application = app
