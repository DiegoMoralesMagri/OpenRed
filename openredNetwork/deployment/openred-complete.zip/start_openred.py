#!/usr/bin/env python3
"""
🚀 OpenRed Startup Script
Démarre automatiquement tous les services OpenRed
"""

import os
import sys
import subprocess
import json

def start_openred():
    print("🚀 Démarrage OpenRed...")
    
    # Charger la configuration
    with open('config.json', 'r') as f:
        config = json.load(f)
    
    print(f"📦 Version: {config['version']}")
    print(f"🌟 Fonctionnalités: {', '.join(config['features'])}")
    
    # Démarrer le serveur web si activé
    if config['installation']['enable_web']:
        web_dir = 'openred-p2p-platform/web/backend'
        if os.path.exists(web_dir):
            print("🌐 Démarrage du serveur web...")
            os.chdir(web_dir)
            subprocess.Popen([sys.executable, 'web_api.py'])
            print("✅ Serveur web démarré sur http://localhost:8000")
    
    print("🎉 OpenRed démarré avec succès!")

if __name__ == "__main__":
    start_openred()
